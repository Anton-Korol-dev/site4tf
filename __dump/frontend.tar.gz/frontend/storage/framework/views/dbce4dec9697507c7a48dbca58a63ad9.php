<?php $__env->startSection('contents'); ?>
    <?php if(!empty($item->id)): ?>
        <ul>
            <li><a href="#toc0">Способность</a></li>
            <?php if(count($stats) > 0): ?>
                <li><a href="#toc1">Статистика</a></li>
            <?php endif; ?>
        </ul>
        
        <h2 id="toc0">Способность</h2>

        <div class="capabilities">
            <?php echo $item->capability; ?>

        </div>

        <?php if($item->image || $item->image2): ?>
        <table class="wiki-combat-content-table">
            <colgroup span="2">
                <col span="2" class="sides_of_combat-mods_table">
            </colgroup>
            <?php if($item->image): ?>
                <tr>
                    <td><center>Бот Мод</center></td>
                    <td><img class="combat-mods" src="/images/Combat-bots/<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>-бот-мод"></td>
                </tr>
            <?php endif; ?>
            <?php if($item->image2): ?>
                <tr>
                    <td><center>Альт Мод</center></td>
                    <td><img class="combat-mods" src="/images/Combat-bots/<?php echo e($item->image2); ?>" alt="<?php echo e($item->name); ?>-бот-мод"></td>
                </tr>
            <?php endif; ?>
            <th><?php echo e($item->name); ?></th>
            <th>
                <?php if($item->fraction == 'autobot'): ?>
                    <img src="/images/Logo/Logo_Autobots.png" alt="Автобот" width="48"> Автобот
                <?php elseif($item->fraction == 'decepticon'): ?>
                    <img src="/images/Logo/Logo_Decepticons.png" alt="Десептикон" width="48"> Десептикон
                <?php else: ?>
                    ???
                <?php endif; ?>
            </th>
        </table>
        <?php endif; ?>

        <?php if(count($stats) > 0): ?>
            <h2 id="toc1">Статистика</h2>
            <table class="wiki-content-table">
                <thead>
                    <tr>
                        <th>Уровень</th>
                        <th>⭐⭐<br>Количество Искры К.О.М.Б.А.Т. / <?php echo e($item->char_name); ?></th>
                        <th>⭐⭐⭐<br>Количество Искры К.О.М.Б.А.Т. / <?php echo e($item->char_name); ?></th>
                        <th>⭐⭐⭐⭐<br>Количество Искры К.О.М.Б.А.Т. / <?php echo e($item->char_name); ?></th>
                        <th>⭐⭐⭐⭐⭐<br>Количество Искры К.О.М.Б.А.Т. / <?php echo e($item->char_name); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->level); ?></td>
                        <td><?php echo e($item->s2); ?></td>
                        <td><?php echo e($item->s3); ?></td>
                        <td><?php echo e($item->s4); ?></td>
                        <td><?php echo e($item->s5); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php else: ?>
        No combat bot found
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anton/projects/site4tf/frontend/resources/views/combats-entry.blade.php ENDPATH**/ ?>