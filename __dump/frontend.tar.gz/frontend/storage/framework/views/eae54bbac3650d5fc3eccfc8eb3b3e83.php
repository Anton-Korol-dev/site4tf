<?php $__env->startSection('contents'); ?>
    <?php if(count($items) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Fraction</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td>
                        <a href="/combat-bots/<?php echo e($item->id); ?>">
                            <?php echo e($item->name); ?>

                        </a>
                    </td>
                    <td>
                        <?php if($item->fraction == 'autobot'): ?>
                            <img src="/images/Logo/Logo_Autobots.png" alt="Автобот" width="48"> Автобот
                        <?php elseif($item->fraction == 'decepticon'): ?>
                            <img src="/images/Logo/Logo_Decepticons.png" alt="Десептикон" width="48"> Десептикон
                        <?php else: ?>
                            ???
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="bg-error">
            No records founds
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anton/projects/site4tf/frontend/resources/views/combats.blade.php ENDPATH**/ ?>